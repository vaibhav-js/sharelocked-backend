# InShare - easy file sharing
Simple file sharing web app with drag and drop file upload

![demo gif](https://github.com/ShivamJoker/GIF-Demos/raw/master/inshare%20demo.gif)

### Backend NodeJS codes can be found on @codersgyan Github
https://github.com/codersgyan/inshare-apis
